<?php
require_once 'connection.php';


 if($conn == true) {
    echo "Connecting successfully";
    if ($_POST) {
        $name = $_POST['name'];
        $pwd = $_POST['pass1'];
        $pwd2 = $_POST['pass2'];
        $role_id = $_POST['roleid'];

        function validatePassword($password)
        {

            // Check password length

            if (strlen($password) < 8) {

                return false;

            }


            // Check for uppercase letter

            if (!preg_match('/[A-Z]/', $password)) {

                return false;

            }


            // Check for lowercase letter

            if (!preg_match('/[a-z]/', $password)) {

                return false;

            }


            // Check for digit

            if (!preg_match('/\d/', $password)) {

                return false;

            }


            // Check for special character

            if (!preg_match('/[^A-Za-z0-9]/', $password)) {

                return false;

            }


            return true;

        }


        // Example usage:



        if (validatePassword($pwd)) {
            if ($pwd == $pwd2) {
                $sql = "INSERT into login(uname,pwd,role_id) values('" . $name . "','" . $pwd . "','" . $role_id . "')";
                $result = mysqli_query($conn, $sql);
                if ($result === true) {
                    $mess = "added";
                    //    alert($name,$mess);
                    echo $name + " " + $mess;

                } else {
                    $mess = "not added";
                    echo $name + " " + $mess;
                }


            }


        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="./style.css">
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2>Sign Up Page</h2>
                <form id="signup-form" action="" method="post">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Enter name">
                    </div>
                    <div class="form-group">
                        <label for="mobile">Mobile:</label>
                        <input type="tel" class="form-control" name="mobile" id="mobile"
                            placeholder="Enter mobile number">
                    </div>
                    <div class="form-group">
                        <label for="create-password">Create Password:</label>
                        <input type="password" class="form-control" name="pass1" id="create-password"
                            placeholder="Enter password">
                    </div>
                    <div class="form-group">
                        <label for="confirm-password">Confirm Password:</label>
                        <input type="password" class="form-control" name="pass2" id="confirm-password"
                            placeholder="Confirm password">
                    </div>
                   
                    <button type="submit" class="btn btn-primary">Sign Up</button>
                </form>
                <p class="signup-link">Already have an account? <a href="./index.php">Login</a>
                </p>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="script.js"></script>
</body>

</html>