<?php
session_start();
// $uname=$_SESSION['username'];
$name="";
$pwd="";
$mess="";
$status="";
$conn = mysqli_connect("localhost", "root", " ", "login");
     
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else{
    echo "Connecting successfully";
if($_POST)
{
    $name=$_POST['name'];
    $pwd=$_POST['pass1'];
    $pwd2=$_POST['pass2'];
    $status=$_POST['email'];
    $year=$_POST['mobile'];
    $sql="INSERT into login(uname,pwd,status,year) values('".$name."','".$pwd."','".$status."','".$year."')";
    $result=mysqli_query($conn,$sql);
    if($result===true)
    {
       $mess="added";
    //    alert($name,$mess);
    echo $name + " "+$mess;

    }
    else
    {
        $mess="not added";
        echo $name + " "+$mess;
    }
}
}
?>
