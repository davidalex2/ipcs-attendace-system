// script.js

// Get the form element
const sendOpt = document.getElementById('s-opt-btn');

// Add event listener to the form
sendOpt.addEventListener('click', (e) => {
    e.preventDefault();

    // Get the input values
    const email = document.getElementById('email').value;
    const otp = document.getElementById('otp').value;

    // Validate the input values
    if (email === '') {
        alert('Please enter your email');
        return;
    }

    // Send the OTP to the email (replace with your API endpoint)
    console.log('Sending OTP to:', email);

    // Simulate OTP sending (replace with your API endpoint)
    setTimeout(() => {
        // Display new password fields
        document.getElementById('new-password-fields').style.display = 'block';

        // Add event listener to the new password form
        document.getElementById('new-password-fields').addEventListener('submit', (e) => {
            e.preventDefault();

            // Get the new password values
            const newPassword = document.getElementById('new-password').value;
            const confirmPassword = document.getElementById('confirm-password').value;

            // Validate the new password values
            if (newPassword === '' || confirmPassword === '') {
                alert('Please fill in all fields');
                return;
            }

            // Check if new passwords match
            if (newPassword !== confirmPassword) {
                alert('New passwords do not match');
                return;
            }

            // Reset the password (replace with your API endpoint)
            console.log('Password reset successfully:', newPassword);
        });
    }, 2000);
});