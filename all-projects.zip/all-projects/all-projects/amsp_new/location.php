<!DOCTYPE html>
<html>
  <head>
    <title>Get Current Location</title>
  </head>
  <body>
    <h1>Get Current Location</h1>
    <button onclick="getLocation()">Get Location</button>
    <p id="location"></p>

    <script>
      function getLocation() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(showPosition);
        } else {
          document.getElementById("location").innerHTML = "Geolocation is not supported by this browser.";
        }
      }

      function showPosition(position) {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        document.getElementById("location").innerHTML = "Latitude: " + latitude + "<br>Longitude: " + longitude;
      }
    </script>
  </body>
</html>