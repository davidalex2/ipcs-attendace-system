<?php
require_once 'connection.php';

if ($conn == true) {
    // echo "Connecting successfully";
    if ($_POST) {
        $username = $_POST["name"];
        $password = $_POST["pass"];
        $sql = "SELECT * FROM login WHERE uname='$username' AND pass='$password'";

        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        $count = mysqli_num_rows($result);

        if ($count == 1 && $row["role_id"] == "1") {
            $_SESSION['login'] = true;
            // echo "login successful";
            header("Location: mainpage.php");//admin/login.
            exit();
        } else if ($count == 1 && $row["role_id"] == "2") {
            $_SESSION["login"] = true;
            echo "employee logged in";
            // header("Location: employeepage.php");//employee.php
            exit();
        } else if ($count == 1 && $row["role_id"] == "3") {
            $_SESSION["login"] = true;
            echo "student logged in";
            // header("Location: studentpage.php");//student.php
            exit();

        } else {
            echo "Invalid username or password";
            session_destroy();
            exit();
        }

        //         else if($count == 1 && $row["status"] == "student"){
//             $rs = mysqli_query($conn,"select * from info");
// }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="./style.css">
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2>Login Page</h2>
                <form id="login-form" action="#" method="POST">
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="text" class="form-control" name="name" id="email" placeholder="Enter email">
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" name="pass" id="password"
                            placeholder="Enter password">
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
                <p class="forgot-password"></p>
                Forgot your password contact the admin
                 <!-- <a href="#">Click here</a> -->
                </p>
                <!-- <p class="signup-link"><a href="./signup.php">Create Account</a>
                </p> -->
                </p>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <!-- <script src="script.js"></script> -->
</body>

</html>