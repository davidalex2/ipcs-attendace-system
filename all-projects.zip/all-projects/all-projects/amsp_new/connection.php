<?php
session_start();
$err="";
$_SESSION['username']="";
$_SESSION['login'] = false;
$conn = mysqli_connect("localhost", "root", "", "ipcs_att");   
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>