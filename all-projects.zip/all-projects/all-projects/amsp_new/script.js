// script.js

// Get the form element
const loginForm = document.getElementById("login-form");

// Add event listener to the form
loginForm.addEventListener("submit", (e) => {
  e.preventDefault();

  // Get the input values
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  // Validate the input values
  if (email === "" || password === "") {
    alert("Please fill in all fields");
    return;
  }

  // Send the data to the server (replace with your API endpoint)
  console.log("Login data:", { email, password });
});

const signupForm = document.getElementById("signup-form");

// Add event listener to the form

signupForm.addEventListener("submit", (e) => {
  e.preventDefault();

  // Get the input values

  const name = document.getElementById("name").value;

  const mobile = document.getElementById("mobile").value;

  const createPassword = document.getElementById("create-password").value;

  const confirmPassword = document.getElementById("confirm-password").value;

  const email = document.getElementById("email").value;

  // Validate the input values

  if (
    name === "" ||
    mobile === "" ||
    createPassword === "" ||
    confirmPassword === "" ||
    email === ""
  ) {
    alert("Please fill in all fields");

    return;
  }

  // Check if passwords match

  if (createPassword !== confirmPassword) {
    alert("Passwords do not match");

    return;
  }

  // Send the data to the server (replace with your API endpoint)

  console.log("Sign up data:", { name, mobile, createPassword, email });
});
